import jwt from "jsonwebtoken";
import { env } from "./env.js";

export type JwtPayload = { userId: string; role: "CLIENT" | "ADMIN" };

export const signAccessToken = (payload: JwtPayload) =>
  jwt.sign(payload, env.ACCESS_TOKEN_SECRET, { expiresIn: "15m" });

export const signRefreshToken = (payload: JwtPayload) =>
  jwt.sign(payload, env.REFRESH_TOKEN_SECRET, { expiresIn: "30d" });

export const verifyAccessToken = (token: string) => jwt.verify(token, env.ACCESS_TOKEN_SECRET) as JwtPayload;

export const verifyRefreshToken = (token: string) => jwt.verify(token, env.REFRESH_TOKEN_SECRET) as JwtPayload;
