import { prisma } from "../config/database.js";
import type { Prisma } from "@prisma/client";

/**
 * Quelques produits actifs par catégorie, du plus récent au plus ancien, avec
 * une seule image chacun : de quoi composer la vignette « Nos univers » côté
 * vitrine sans charger tout le catalogue. On prend l'image de la première
 * déclinaison active, sinon un visuel commun de la fiche.
 */
const categoryListInclude = {
  _count: { select: { products: true } },
  // Quelques produits actifs par catégorie, du plus récent au plus ancien, avec
  // une seule image chacun : de quoi composer la vignette « Nos univers » côté
  // vitrine sans charger tout le catalogue. Image de la première déclinaison
  // active, sinon un visuel commun de la fiche.
  products: {
    where: { active: true },
    orderBy: { createdAt: "desc" },
    take: 8,
    select: {
      name: true,
      images: { orderBy: { position: "asc" }, take: 1, select: { url: true, alt: true } },
      variants: {
        where: { active: true },
        orderBy: { position: "asc" },
        take: 1,
        select: { images: { orderBy: { position: "asc" }, take: 1, select: { url: true, alt: true } } },
      },
    },
  },
} satisfies Prisma.CategoryInclude;

export type CategoryWithPreview = Prisma.CategoryGetPayload<{ include: typeof categoryListInclude }>;

export const categoryRepository = {
  findAll: () =>
    prisma.category.findMany({
      include: categoryListInclude,
      orderBy: [{ position: "asc" }, { createdAt: "asc" }],
    }),
  findById: (id: string) => prisma.category.findUnique({ where: { id } }),
  existsById: async (id: string) => (await prisma.category.count({ where: { id } })) > 0,
  findByName: (name: string) => prisma.category.findUnique({ where: { name } }),
  findBySlug: (slug: string) => prisma.category.findUnique({ where: { slug } }),
  countProducts: (id: string) => prisma.product.count({ where: { categoryId: id } }),
  create: (data: Prisma.CategoryCreateInput) => prisma.category.create({ data }),
  update: (id: string, data: Prisma.CategoryUpdateInput) => prisma.category.update({ where: { id }, data }),
  remove: (id: string) => prisma.category.delete({ where: { id } }),
};
