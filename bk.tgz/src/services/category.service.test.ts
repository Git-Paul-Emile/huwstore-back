import { afterEach, describe, it, mock } from "node:test";
import assert from "node:assert/strict";
import { categoryRepository } from "../repositories/category.repository.js";
import { categoryService } from "./category.service.js";

type RepoCategory = Awaited<ReturnType<typeof categoryRepository.findAll>>[number];

const product = (name: string, variantImage?: string, productImage?: string) => ({
  name,
  images: productImage ? [{ url: productImage, alt: name }] : [],
  variants: variantImage ? [{ images: [{ url: variantImage, alt: name }] }] : [],
});

const category = (over: Partial<RepoCategory> = {}) =>
  ({
    id: "c1",
    name: "Cabas",
    slug: "cabas",
    image: "/univers/cabas.webp",
    description: null,
    position: 0,
    createdAt: new Date(),
    updatedAt: new Date(),
    _count: { products: 12 },
    products: [],
    ...over,
  }) as unknown as RepoCategory;

describe("categoryService.list", () => {
  afterEach(() => mock.restoreAll());

  it("compose la couverture depuis les produits : image de déclinaison, sinon image de fiche", async () => {
    mock.method(categoryRepository, "findAll", async () => [
      category({
        products: [
          product("Sac A", "https://cdn/a-variant.jpg"),
          product("Sac B", undefined, "https://cdn/b-produit.jpg"),
        ],
      }),
    ]);

    const [dto] = await categoryService.list();

    assert.deepEqual(
      dto.preview.map((p) => p.url),
      ["https://cdn/a-variant.jpg", "https://cdn/b-produit.jpg"],
    );
  });

  it("dédoublonne et plafonne la couverture à 4 visuels", async () => {
    mock.method(categoryRepository, "findAll", async () => [
      category({
        products: [
          product("A", "https://cdn/1.jpg"),
          product("B", "https://cdn/1.jpg"),
          product("C", "https://cdn/2.jpg"),
          product("D", "https://cdn/3.jpg"),
          product("E", "https://cdn/4.jpg"),
          product("F", "https://cdn/5.jpg"),
        ],
      }),
    ]);

    const [dto] = await categoryService.list();
    assert.deepEqual(
      dto.preview.map((p) => p.url),
      ["https://cdn/1.jpg", "https://cdn/2.jpg", "https://cdn/3.jpg", "https://cdn/4.jpg"],
    );
  });

  it("une image choisie au back-office prime sur la mosaïque de produits", async () => {
    mock.method(categoryRepository, "findAll", async () => [
      category({
        image: "https://cdn/univers-toile-coton.jpg",
        products: [product("Sac A", "https://cdn/a.jpg"), product("Sac B", "https://cdn/b.jpg")],
      }),
    ]);

    const [dto] = await categoryService.list();
    assert.deepEqual(dto.preview, [{ url: "https://cdn/univers-toile-coton.jpg", alt: "Cabas" }]);
  });

  it("garde la mosaïque produits quand l'image est le visuel de départ (local ou Cloudinary)", async () => {
    for (const image of [
      "/univers/toile-coton.webp",
      "https://res.cloudinary.com/xyz/image/upload/v1/huwstore/univers/toile-coton.webp",
    ]) {
      mock.restoreAll();
      mock.method(categoryRepository, "findAll", async () => [
        category({ image, products: [product("Sac A", "https://cdn/a.jpg")] }),
      ]);

      const [dto] = await categoryService.list();
      assert.deepEqual(
        dto.preview.map((p) => p.url),
        ["https://cdn/a.jpg"],
        `échec pour image = ${image}`,
      );
    }
  });

  it("renvoie une couverture vide pour un univers sans produit ni image choisie, et ne fuit pas les colonnes ORM", async () => {
    mock.method(categoryRepository, "findAll", async () => [
      category({ image: "/univers/cabas.webp", products: [] }),
    ]);

    const [dto] = await categoryService.list();

    assert.deepEqual(dto.preview, []);
    assert.equal(dto.image, "/univers/cabas.webp");
    assert.ok(!("createdAt" in dto));
    assert.ok(!("updatedAt" in dto));
  });
});
