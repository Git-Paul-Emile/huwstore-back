import { categoryRepository, type CategoryWithPreview } from "../repositories/category.repository.js";
import { AppError } from "../utils/AppError.js";
import { slugify } from "../utils/slugify.js";
import type { categorySchema, categoryUpdateSchema } from "../validators/category.validator.js";
import type { z } from "zod";

/** Nombre de visuels retenus pour la vignette « Nos univers ». */
const PREVIEW_SIZE = 4;

/**
 * Le visuel de DÉPART d'un univers, qu'il soit servi en local (`/univers/x.webp`)
 * ou depuis Cloudinary (`.../huwstore/univers/x.webp` produit par
 * `npm run media:upload`). Ce n'est pas un choix de la boutique : c'est le
 * repli, la mosaïque de produits doit primer dessus.
 */
const isSeedDefaultImage = (url: string) => url.startsWith("/univers/") || url.includes("/huwstore/univers/");

/**
 * `true` quand la boutique a téléversé sa propre image pour l'univers depuis le
 * back-office (elle atterrit dans `huwstore/categories/`). Dans ce cas, ce choix
 * prime sur la couverture composée des produits.
 */
const isChosenImage = (url: string) => Boolean(url) && !isSeedDefaultImage(url);

/**
 * DTO d'un univers pour la vitrine (rules/architecture.md : le service ne
 * renvoie pas l'objet ORM brut).
 *
 * `preview` porte les visuels de la vignette d'accueil. Par défaut c'est une
 * sélection de photos de produits réellement présents dans la catégorie. Mais
 * si la boutique a choisi une image pour l'univers depuis le back-office, cette
 * image prime : la mosaïque automatique ne rend pas toujours bien selon les
 * photos produit, la boutique garde donc la main.
 */
function toDto(category: CategoryWithPreview) {
  const preview: { url: string; alt: string }[] = [];

  if (isChosenImage(category.image)) {
    preview.push({ url: category.image, alt: category.name });
  } else {
    for (const product of category.products) {
      const image = product.variants[0]?.images[0] ?? product.images[0];
      if (image && !preview.some((entry) => entry.url === image.url)) {
        preview.push({ url: image.url, alt: image.alt || `${category.name} - ${product.name}` });
      }
      if (preview.length === PREVIEW_SIZE) break;
    }
  }

  return {
    id: category.id,
    name: category.name,
    slug: category.slug,
    image: category.image,
    description: category.description,
    position: category.position,
    _count: category._count,
    preview,
  };
}

export const categoryService = {
  async list() {
    const categories = await categoryRepository.findAll();
    return categories.map(toDto);
  },

  async create(input: z.infer<typeof categorySchema>) {
    const existing = await categoryRepository.findByName(input.name);
    if (existing) throw AppError.conflict("Cette catégorie existe déjà.");
    return categoryRepository.create({ ...input, slug: input.slug ?? slugify(input.name) });
  },

  async update(id: string, input: z.infer<typeof categoryUpdateSchema>) {
    const category = await categoryRepository.findById(id);
    if (!category) throw AppError.notFound("Catégorie introuvable.");
    return categoryRepository.update(id, input);
  },

  async remove(id: string) {
    const category = await categoryRepository.findById(id);
    if (!category) throw AppError.notFound("Catégorie introuvable.");

    // Une catégorie encore rattachée à des produits ne peut pas disparaître :
    // la contrainte de clé étrangère lèverait une 500 illisible.
    const count = await categoryRepository.countProducts(id);
    if (count > 0) throw AppError.conflict(`Cette catégorie contient encore ${count} produit(s).`);

    await categoryRepository.remove(id);
  },
};
